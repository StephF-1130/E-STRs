# gtex-estrs
Analyzing eSTRs in GTEx data
